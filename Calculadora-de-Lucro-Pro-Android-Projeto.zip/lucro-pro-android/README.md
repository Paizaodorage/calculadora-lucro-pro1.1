# Calculadora de Lucro Pro — projeto Android

Este projeto empacota a versão HTML única em um app Android nativo simples (WebView). A tela e os cálculos rodam localmente; o perfil, produtos e histórico ficam no armazenamento local do app. Não há sincronização central de divergências ainda.

## Construir APK com Android Studio

1. Extraia o ZIP em um computador.
2. Instale Android Studio (inclui/permite instalar Android SDK 35) e Java 17.
3. Abra a pasta `lucro-pro-android` no Android Studio.
4. Aceite a sincronização do Gradle e instale o Android SDK Platform 35 se solicitado.
5. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK de teste ficará em `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfira o APK para o celular Android e instale. Pode ser necessário permitir instalação pelo app usado para abrir o arquivo.

## Construir APK sem Android Studio (GitHub Actions)

O projeto inclui `.github/workflows/build-apk.yml`. Crie um repositório GitHub vazio, envie os arquivos desta pasta para a branch `main` e abra **Actions > Build APK > Run workflow**. Ao concluir, baixe o artefato `calculadora-lucro-pro-debug-apk` na execução.

O APK gerado por esse fluxo é um APK de depuração, adequado para teste pessoal. Para distribuição pública, criar uma versão release assinada com chave própria e guardar a chave com segurança.

## Notas técnicas

- `minSdk 29` (Android 10 ou superior) para exportar arquivos pela pasta Downloads com armazenamento moderno.
- A calculadora é empacotada em `app/src/main/assets/index.html` e abre via `WebViewAssetLoader` para permitir IndexedDB/localStorage persistentes.
- Exportações CSV/JSON usam uma ponte nativa e salvam em Downloads; a importação abre o seletor de documentos Android.
- Links externos HTTPS abrem no navegador do dispositivo.
- O APK não inclui backend de sincronização; logs de divergências ficam no aparelho e devem ser exportados até conectar um servidor.
